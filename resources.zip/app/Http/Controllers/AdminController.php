<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AdminController extends Controller
{
    public function index(){
        $datas['buys']=DB::table("buy")->orderBy('id','desc')->limit(5)->get();
        $datas['tbuys']=DB::table("buy")->count();
        $datas['tdbuys']=DB::table("buy")->where('date', 'LIKE', Carbon::now()->toDateString().'%' )->count();
        $datas['tdattempts']=DB::table("request")->where('date', 'LIKE', Carbon::now()->toDateString().'%' )->count();
        return view('admin.dashboard', $datas);
    }

    public function transactions(){
        $datas['buys']=DB::table("buy")->orderBy('id','desc')->paginate(20);
        return view('admin.transactions', $datas);
    }

    public function products(){
        $datas['data']=DB::table("products")->paginate(10);
        return view('admin.products', $datas);
    }

    public function attempts(){
        $datas['buys']=DB::table("request")->paginate(10);
        return view('admin.attempts', $datas);
    }
}
