<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="Buy Cheap MTN, AIRTEL, 9MOBILE and GLO Data Bundles and Aitime with ease" />
        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
          <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
          <script type="text/javascript">
//if(window.location.href.startsWith('http://')){
//window.location.href=window.location.href.replace('http://', 'https://');
//}
</script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <link rel="manifest" href="/js/manifest.json"></link>

        <title><?php echo e(env("TELECOM_NAME")); ?></title>
        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">
    </head>
    <body>

        <!-- Header -->
<header class="w3-display-container w3-content w3-center" style="max-width:1500px">
  <img class="w3-image" src="/images/hand_shake.jpg" alt="Me" width="1500" height="600">
  <div class="w3-display-middle w3-padding-large w3-wide w3-text-light-grey w3-center">
    <h1 class="w3-hide-medium w3-hide-small w3-xxxlarge" style="font-weight: bolder; color: white; margin-top: 50px"><?php echo e(env("TELECOM_NAME")); ?></h1>
    <h3 class="w3-hide-large" style="white-space:nowrap; color: white; font-weight: bolder; margin-top: 70px"> <?php echo e(env("TELECOM_NAME_PART1")); ?> </h3>
    <h4 class="w3-hide-large" style="white-space:nowrap;"><?php echo e(env("TELECOM_NAME_PART2")); ?></h4>

    <p class="w3-hide-large w3-hide-medium" style="font-size: 9px; font-max-size: 14px; color: yellow;">Instant delivery on all networks</p>
      <p class="w3-hide-small w3-hide-medium" style="color: yellow; font-weight: bolder">We have an affordable data plan for you. With online payment options and 24/7 availability, take advantage of our cheap data offering for all networks and do more in every area of your life.</p>
  </div>

  <!-- Navbar (placed at the bottom of the header image) -->
  <div class="w3-bar w3-light-grey w3-round w3-display-bottommiddle w3-hide-small" style="bottom:-16px; font-weight: bolder;">
    <a href="<?php echo e(url('/buydata')); ?>" class="w3-bar-item w3-button">Buy Data</a>
    <a href="<?php echo e(url('/buyairtime')); ?>" class="w3-bar-item w3-button">Buy Airtime</a>
    <a href="<?php echo e(url('/buypaytv')); ?>" class="w3-bar-item w3-button">Tv Subscription</a>
    <a href="#pricing" class="w3-bar-item w3-button">Pricing</a>
  </div>

</header>

<!-- Navbar on small screens -->
<div class="w3-center w3-light-grey w3-padding-16 w3-hide-large w3-hide-medium" style="font-weight: bolder;">
<div class="w3-bar w3-light-grey">
  <a href="<?php echo e(url('/buydata')); ?>" class="w3-bar-item w3-button">Buy Data</a>
  <a href="<?php echo e(url('/buyairtime')); ?>" class="w3-bar-item w3-button">Buy Airtime</a>
  <a href="<?php echo e(url('/buypaytv')); ?>" class="w3-bar-item w3-button">Tv Subscription</a>
    <a href="#pricing" class="w3-bar-item w3-button">Pricing</a>
</div>
</div>
<!-- Page content -->
<div class="w3-content w3-padding-large w3-margin-top" id="pricing">

  <div class="row ">
<div class="column-container">
<div class="column dark-background accent-green box box-landing-1">

    <div class="w3-blue w3-padding-large w3-padding-32 w3-margin-top w3-margin-bottom" id="contact">
        <h2 class="w3-center" style="font-size: 15px">We offer best deals when it comes to internet Data Plans, Airtime and Tv Subscription in Nigeria with a completely hassle-free experience with options of paying through online payment/bank transfer through secured and trusted gateways.</h2>
        <div class="row">
            <div class="col-md-4">
                <h3>SPEED</h3>
                Instant delivery on all networks
            </div>
            <div class="col-md-4">
                <h3>AFFORDABILITY</h3>
                Quality + Affordability + Legitimacy, we are here to serve you the cheapest price
            </div>
            <div class="col-md-4">
                <h3>SUPPORT</h3>
                You are not alone, our customer service is always available for you at all time.
            </div>
        </div>
        <p></p>
        <p style="font-weight: bolder;"></p>
    </div>

<div class="container">
        <div class="row" style="color: white;">

    <div class="col-xs-6 col-sm-4 col-md-2 col-lg-2" style="border-radius: 10px; border-color: yellow; border-width: 2px; border-style: double; margin-left: 30px; padding: 10px; margin-bottom: 30px; color: black; background-color: #013220">
                    <!-- PRICE ITEM -->
                    <div class="panel price panel-yellow">
                        <div class="panel-heading  text-center">
                        <h3>MTN</h3>
                        </div>
                        <div class="panel-body text-center">
                            <p class="lead"><strong>30 days</strong></p>
                        </div>
                        <ul class="list-group list-group-flush text-center">
                            <li class="list-group-item"><i class="icon-ok text-warning"></i>1gb = ₦500</li>
                    <li class="list-group-item"><i class="icon-ok text-warning"></i>2gb = ₦1000</li>
<li class="list-group-item"><i class="icon-ok text-warning"></i> 5gb = ₦2500</li>
                        </ul>
                        <div class="panel-footer">
                            <a class="w3-button w3-block w3-hover-blue w3-border-blue" href="<?php echo e(url('/buydata')); ?>"><span>BUY NOW!</span></a>
                        </div>
                    </div>
                    <!-- /PRICE ITEM -->
                    </div>


                     <div class="col-xs-6 col-sm-4 col-md-2 col-lg-2" style="border-radius: 10px; border-color: red; border-width: 2px; border-style: double; margin-left: 30px; padding: 10px; margin-bottom: 30px; color: black; background-color: #013220">
                    <!-- PRICE ITEM -->
                    <div class="panel price panel-red">
                        <div class="panel-heading arrow_box text-center">
                        <h3>Airtel</h3>
                        </div>
                        <div class="panel-body text-center">
                            <p class="lead"><strong>30 days</strong></p>
                        </div>
                        <ul class="list-group list-group-flush text-center">
    <li class="list-group-item"><i class="icon-ok text-danger"></i>  1.5gb = ₦1000</li>
  <li class="list-group-item"><i class="icon-ok text-danger"></i>3.5GB = ₦2000 </li>
                    <li class="list-group-item"><i class="icon-ok text-danger"></i> 10gb = ₦4850 </li>
<li class="list-group-item"><i class="icon-ok text-danger"></i> 16gb = ₦7800 </li>
<li class="list-group-item"><i class="icon-ok text-danger"></i> 22gb = ₦9850 </li>
                        </ul>
                        <div class="panel-footer">
                            <a class="w3-button w3-block w3-hover-blue w3-border-blue" href="<?php echo e(url('/buydata')); ?>"><span>BUY NOW!</span></a>
                        </div>
                    </div>
                    <!-- /PRICE ITEM -->
                </div> <!-- endy -->


                    <div class="col-xs-6 col-sm-4 col-md-2 col-lg-2" style="border-radius: 10px; border-color: green; border-width: 2px; border-style: double; margin-left: 30px; padding: 10px; margin-bottom: 30px; color: black; background-color: #013220">
                    <!-- PRICE ITEM -->
                    <div class="panel price panel-green">
                        <div class="panel-heading arrow_box text-center">
                        <h3>9mobile</h3>
                        </div>
                        <div class="panel-body text-center">
                            <p class="lead"><strong>30 days</strong></p>
                        </div>
                        <ul class="list-group list-group-flush text-center">
                                <li class="list-group-item"><i class="icon-ok text-primary"></i> 250mb = ₦300</li>
                            <li class="list-group-item"><i class="icon-ok text-success"></i> 1gb = ₦750</li>
  <li class="list-group-item"><i class="icon-ok text-primary"></i> 1.5gb = ₦1100 </li>
                    <li class="list-group-item"><i class="icon-ok text-success"></i> 2gb = ₦1350</li>
<li class="list-group-item"><i class="icon-ok text-primary"></i> 3gb = ₦2050 </li>
<li class="list-group-item"><i class="icon-ok text-primary"></i> 5gb = ₦3180 </li>
                        </ul>
                        <div class="panel-footer">
                            <a class="w3-button w3-block w3-hover-blue w3-border-blue" href="<?php echo e(url('/buydata')); ?>"><span>BUY NOW!</span></a>
                        </div>
                    </div>
                    <!-- /PRICE ITEM -->
                </div>

                    <div class="col-xs-6 col-sm-4 col-md-2 col-lg-2" style="border-radius: 10px; border-color: green; border-width: 2px; border-style: double; margin-left: 30px; padding: 10px; margin-bottom: 30px; color: black; background-color: #013220">
                    <!-- PRICE ITEM -->
                    <div class="panel price panel-green">
                        <div class="panel-heading arrow_box text-center">
                        <h3>GLO</h3>
                        </div>
                        <div class="panel-body text-center">
                            <p class="lead"><strong>30 days</strong></p>
                        </div>
                        <ul class="list-group list-group-flush text-center">
                                <li class="list-group-item"><i class="icon-ok text-success"></i> 1.6GB/2GB = ₦1000 </li>
  <li class="list-group-item"><i class="icon-ok text-primary"></i> 3.65GB/4.5GB = ₦1850 </li>
                    <li class="list-group-item"><i class="icon-ok text-success"></i> 5.75GB/7.2GB = ₦2300 </li>
<li class="list-group-item"><i class="icon-ok text-primary"></i> 7GB/8.25GB = ₦2800 </li>
<li class="list-group-item"><i class="icon-ok text-primary"></i> 10GB/12.5GB = ₦3600 </li>
<li class="list-group-item"><i class="icon-ok text-primary"></i> 12.5GB/15.6GB = ₦4400 </li>
<li class="list-group-item"><i class="icon-ok text-primary"></i> 20GB/25GB = ₦7200 </li>
                        </ul>
                        <div class="panel-footer">
                            <a class="w3-button w3-block w3-hover-blue w3-border-blue" href="<?php echo e(url('/buydata')); ?>"><span>BUY NOW!</span></a>
                        </div>
                    </div>
                    <!-- /PRICE ITEM -->
                </div>

                </div><!-- /row -->
            </div><!-- /container -->
        </div>

</div>
</div>

  <!-- Contact -->
  <div class="w3-padding-large w3-padding-32 w3-margin-top" id="contact">
    <h2 class="w3-center"></h2>
      <div class="row">
          <div class="col-md-4 w3-blue w3-padding-16" align="center">
              <h2><?php echo e(env("TELECOM_SUPPORT_PHONE")); ?></h2>
              <span style="color: floralwhite"> Customer Care</span>
          </div>
          <div class="col-md-4 w3-border-blue w3-animate-opacity" align="center">
              <h2>Support</h2>
              You are not alone

          </div>
          <div class="col-md-4 w3-blue w3-padding-16" align="center">
              <h3><?php echo e(env("TELECOM_SUPPORT_EMAIL")); ?></h3>
              Email

          </div>
      </div>

  </div>

<!-- End page content -->
</div>


        <div class="column dark-background" style="color: white; background-color: darkslategrey; padding: 15px; font-weight: bold;">
            <div align="center">Copyright &copy; 2019 <?php echo e(env("TELECOM_NAME")); ?> &reg; |  <a href="https://www.facebook.com/" style="text-decoration: none">Facebook</a> | <a href="https://wa.me/<?php echo e(env('TELECOM_SUPPORT_PHONE')); ?>" style="color: lightgreen; text-decoration: none">Whatsapp</a> </div>
        </div>
    </body>
      <script src="/js/pwabuilder-sw.js"></script><script src="/js/pwabuilder-sw-register.js"></script>
</html>
<?php /**PATH C:\wamp64\www\laravelProject\lilyonyi\resources\views/welcome.blade.php ENDPATH**/ ?>