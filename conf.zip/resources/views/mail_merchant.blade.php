<h1>Hi, {{ $name }}</h1>
<p>You have a new bank tranfer request from {{ $email }} with the following details.</p>
<p>
	<strong>
Recipient: {{ $recipient }} <br />
Order: {{ $order }} <br />
Price: #{{ $price }} <br />
Bank Narration: {{$narration}} <br />
	</strong>
</p>

<p>Kindly confirm the payment and process the order asap to increase customer trust.<p>
<p>Warm Regards, <br />
------------------<p>
<p><b>5Star Company</b><br/>
info@5starcompany.com.ng<br />
www.5starcompany.com.ng
<p>
